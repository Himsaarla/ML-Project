from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field
from pathlib import Path
from datetime import datetime
import sqlite3, math

ROOT = Path(__file__).resolve().parent
DB = ROOT / "loan_app.db"
app = FastAPI(title="AURELIA Loan Intelligence")
app.mount("/static", StaticFiles(directory=ROOT / "static"), name="static")

def db_init():
    with sqlite3.connect(DB) as c:
        c.execute("""CREATE TABLE IF NOT EXISTS applications(
        id INTEGER PRIMARY KEY AUTOINCREMENT, applicant_name TEXT, email TEXT,
        annual_income REAL, loan_amount REAL, credit_history INTEGER,
        employment_status TEXT, education TEXT, dependents INTEGER,
        probability REAL, prediction TEXT, created_at TEXT)""")
db_init()

class Application(BaseModel):
    applicant_name: str = Field(min_length=2, max_length=80)
    email: str = ""
    annual_income: float = Field(gt=0)
    loan_amount: float = Field(gt=0)
    credit_history: int = Field(ge=0, le=1)
    employment_status: str
    education: str
    dependents: int = Field(ge=0, le=15)

def demo_score(d):
    # Demonstration heuristic only; replace with a validated trained ML model.
    income, loan = d["annual_income"], d["loan_amount"]
    s = 50 + (24 if d["credit_history"] else -25)
    s += max(-12, min(12, (income - 500000) / 100000))
    ratio = loan / max(income, 1)
    s += 14 if ratio <= .25 else 5 if ratio <= .45 else -10 if ratio <= .7 else -22
    s += 8 if d["employment_status"] == "Salaried" else 3 if d["employment_status"] == "Self-employed" else -7
    s += 3 if d["education"] == "Graduate" else 0
    s -= max(0, d["dependents"] - 1) * 2
    return round(max(1, min(99, 100/(1+math.exp(-(s-50)/14)))), 1)

@app.get("/")
def home(): return FileResponse(ROOT / "static" / "index.html")

@app.get("/api/health")
def health(): return {"status":"ok", "mode":"demonstration"}

@app.post("/api/predict")
def predict(a: Application):
    if a.employment_status not in {"Salaried","Self-employed","Unemployed"}: raise HTTPException(422,"Invalid employment status")
    if a.education not in {"Graduate","Non-graduate"}: raise HTTPException(422,"Invalid education")
    d = a.model_dump()
    p = demo_score(d)
    label = "Likely approved" if p >= 55 else "Needs review"
    created = datetime.now().isoformat(timespec="seconds")
    with sqlite3.connect(DB) as c:
        cur = c.execute("INSERT INTO applications(applicant_name,email,annual_income,loan_amount,credit_history,employment_status,education,dependents,probability,prediction,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)",
        (d["applicant_name"],d["email"],d["annual_income"],d["loan_amount"],d["credit_history"],d["employment_status"],d["education"],d["dependents"],p,label,created))
        ident = cur.lastrowid
    return {"id":ident,"probability":p,"prediction":label,"created_at":created,"disclaimer":"Illustrative demo only, not a credit decision."}

@app.get("/api/dashboard")
def dashboard():
    with sqlite3.connect(DB) as c:
        c.row_factory = sqlite3.Row
        total = c.execute("SELECT COUNT(*) n FROM applications").fetchone()["n"]
        avg = c.execute("SELECT AVG(probability) a FROM applications").fetchone()["a"] or 0
        approved = c.execute("SELECT COUNT(*) n FROM applications WHERE prediction='Likely approved'").fetchone()["n"]
        recent = c.execute("SELECT id,applicant_name,loan_amount,probability,prediction,created_at FROM applications ORDER BY id DESC LIMIT 8").fetchall()
    return {"total":total,"average_probability":round(avg,1),"likely_approved":approved,"review_count":total-approved,"recent":[dict(x) for x in recent]}

@app.get("/api/applications")
def applications():
    with sqlite3.connect(DB) as c:
        c.row_factory = sqlite3.Row
        rows = c.execute("SELECT * FROM applications ORDER BY id DESC LIMIT 100").fetchall()
    return [dict(x) for x in rows]

@app.delete("/api/applications/{ident}")
def delete_application(ident:int):
    with sqlite3.connect(DB) as c:
        cur = c.execute("DELETE FROM applications WHERE id=?", (ident,))
        if not cur.rowcount: raise HTTPException(404,"Application not found")
    return {"deleted":True}
