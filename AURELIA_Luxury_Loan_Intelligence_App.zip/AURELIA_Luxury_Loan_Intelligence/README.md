# AURELIA — Luxury Loan Intelligence
A full-stack demo application for the Loan Approval Prediction project.

## Run on Windows
1. Extract the ZIP.
2. Open Command Prompt in this folder.
3. Run:
   ```
   py -m venv .venv
   .venv\Scripts\activate
   pip install -r requirements.txt
   uvicorn app:app --reload
   ```
4. Open http://127.0.0.1:8000. API docs: http://127.0.0.1:8000/docs

## Features
- Luxury responsive dashboard, applicant form, assessment results, application history
- FastAPI REST backend, SQLite database, validation, delete endpoint
- Endpoints: GET /api/health, POST /api/predict, GET /api/dashboard, GET /api/applications, DELETE /api/applications/{id}

## Important
The app uses a transparent demo scoring heuristic so it works immediately. It is NOT a trained Random Forest, XGBoost or LightGBM model and must never be used for real credit decisions. Replace `demo_score()` with a properly trained and evaluated model before presenting predictions as machine-learning results. Your project presentation names Random Forest, XGBoost and LightGBM as the intended algorithms; these are shown as planned integrations in the UI.
